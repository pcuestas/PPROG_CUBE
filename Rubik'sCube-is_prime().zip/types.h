
#ifndef TYPES_H
#define TYPES_H


typedef enum {FALSE=0,TRUE=1} Bool;

typedef enum { ERROR=0,OK=1} Status;

#endif 